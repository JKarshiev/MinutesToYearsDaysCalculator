public class MinutesToYearsDaysCalculator {
    public static void main(String[] args) {
        printYearsAndDays(561600);
    }
    public static void printYearsAndDays(long minutes){
        if (minutes > 0){
            long year = minutes % 525600;
            long year1 = minutes / 525600;
            if (year == 0){
                System.out.println(minutes + " min = " + year1 + " y and 0 d");
            }else {
                long days = year / 1440;
                System.out.println(minutes + " min = " + year1 + " y and " + days + " d");
            }
        }else {
            System.out.println("Invalid Value");
        }
    }
}
